const { FEED } =require('../model/FEED')

const getFeed = (req, res) => {
    FEED.find()
        .then(result=>
            res.render('index', { result, err:false }))
        .catch(err => console.log(err))
}


const newFeed = (req, res) => {
    // console.log(req.body)
    if(req.method === 'GET'){
        res.render('index',{err:false})
    }
    if(req.method === 'POST'){
        // console.log(req.body)  
        const feed = new FEED(req.body)
        feed.save()
        // console.log(req.body);
        .then(result=>res.redirect('/feed'))
        // .catch(err => console.log(err.errors.name.message))
        .catch(err => {
            FEED.find()
                .then(result=>
                    res.render('index', {result, err: err.errors} ))
                .catch(err => console.log(err))
        })
    }
}
const showOneCard = (req,res) =>{
    FEED.findById({_id: req.params.id })
    .then(result=>{ 
        // console.log(result)
        res.render('showCard', { result })
    })
        
    .catch(err => console.log(err))
}


const editOneCard = (req, res) =>{
    if(req.method === 'GET'){
    FEED.findById({_id: req.params.id })
    .then(result=>{ 
        res.render('editCard', { result, err:false  })
    })
    .catch(err => console.log(err))
    }

    if(req.method === 'POST'){
        FEED.findByIdAndUpdate({_id: req.params.id})
            .then(result=>{
                result.name = req.body.name
                result.message = req.body.message
                result.save()
                    .then( ()=> {
                        res.render('showCard', { result })})
                    .catch(err => {
                        res.render('index', {result, err: err.errors} )

                    })
            })
            .catch(err => console.log(err))
        }
}










const deleteCard = (req,res) =>{
    FEED.findByIdAndDelete({_id: req.params.id })
    .then(result=>res.redirect('/feed'))
    .catch(err => console.log(err))
}















module.exports = {
    getFeed,
    newFeed,
    showOneCard,
    editOneCard,
    deleteCard
}