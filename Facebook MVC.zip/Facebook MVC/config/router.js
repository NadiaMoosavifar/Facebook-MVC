const express = require('express')
const router = express.Router()

const controller = require('../controllers/controller')

router.get('/feed', controller.getFeed)
router.all('/feed', controller.newFeed)
router.get('/feed/:id', controller.showOneCard)
router.get('/delete/:id', controller.deleteCard)
router.all('/edit/:id', controller.editOneCard)







module.exports = router
