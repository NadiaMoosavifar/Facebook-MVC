const mongoose = require('mongoose')

const my_db = "mongodb://localhost/exam"

mongoose.connect(my_db, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(res => console.log('connected to db'))
    .catch(err=> console.log(err))