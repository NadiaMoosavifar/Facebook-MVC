const mongoose = require('mongoose')
const Schema = mongoose.Schema

const feedSchema = new Schema({
    name : {
        type:String,
        required:true,
        maxlength:15
    },
    message : {
        type:String,
        required:true,
        maxlength:40
    },
    created_at    : { type: Date, required: true, default: Date.now }
}, {timestamps:true})

const FEED = mongoose.model('Article', feedSchema)

module.exports ={
    FEED
}